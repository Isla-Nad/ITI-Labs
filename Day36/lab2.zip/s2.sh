echo $x
