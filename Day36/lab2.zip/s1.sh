export x=5
# . s2.sh
s2.sh
